export interface LocationDetails {

    id:number;
    location_id: string;
    location_name: string;
    create_user_id: string;
    create_date_time: string;
    update_user_id: string;
    update_date_time: string;
}
