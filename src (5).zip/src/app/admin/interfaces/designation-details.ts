export interface DesignationDetails {

    id:number;
    role_id: string;
    role_name: string;
    can_review: string;
    create_user_id: string;
    create_date_time: string;
    update_user_id: string;
    update_date_time: string;
}
