export interface BusinessunitDetails {

    id:number;
    bu_id: string;
    bu_name: string;
    description: string;
    create_user_id: string;
    create_date_time: string;
    update_user_id: string;
    update_date_time: string;
}
