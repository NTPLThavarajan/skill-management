import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SkillmasterComponent } from './skillmaster/skillmaster.component';

//Angular System UI Module
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import { FormsModule,ReactiveFormsModule  } from '@angular/forms';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSelectModule} from '@angular/material/select';
import {MatIconModule} from '@angular/material/icon';
import { UserAddComponent } from './user-add/user-add.component';
import { UseraddDialogComponent } from './user-add/useradd-dialog/useradd-dialog.component';
import{MatSortModule} from'@angular/material/sort';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatMenuModule } from "@angular/material/menu";
import { LocationmasterComponent } from './locationmaster/locationmaster.component';
import { LocationdialogComponent } from './locationmaster/locationdialog/locationdialog.component';
import { RatingmasterComponent } from './ratingmaster/ratingmaster.component';
import { RatingdialogComponent } from './ratingmaster/ratingdialog/ratingdialog.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { SkilldialogComponent } from './skillmaster/skilldialog/skilldialog.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { RolldialogComponent } from './rollmaster/rolldialog/rolldialog.component';
import { RollmasterComponent } from './rollmaster/rollmaster.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {SpinnerDialogComponent } from '../commoncomponent/spinnerdialog.component';
import { AppRoutingModule } from './app-routing.module';
import { HomelinkComponent } from './homelink/homelink.component';

@NgModule({
  declarations: [SkillmasterComponent,UserAddComponent,UseraddDialogComponent,
     LocationmasterComponent, 
    LocationdialogComponent, RatingmasterComponent, RatingdialogComponent,
    SkilldialogComponent, RolldialogComponent,RollmasterComponent, HomelinkComponent],
 
  imports: [CommonModule,BrowserAnimationsModule,RouterModule,MatButtonModule,MatInputModule,
    MatCardModule,FormsModule,ReactiveFormsModule,MatPaginatorModule,MatTableModule,
    MatGridListModule,MatDialogModule,MatSelectModule,MatIconModule,MatSortModule,
    MatTooltipModule,MatToolbarModule,MatMenuModule,MatProgressSpinnerModule,
    MatAutocompleteModule,MatCheckboxModule,AppRoutingModule],
 
    exports: [SkillmasterComponent,UserAddComponent,UseraddDialogComponent,
      LocationmasterComponent, LocationdialogComponent,RolldialogComponent,
      RollmasterComponent,RatingmasterComponent, RatingdialogComponent,HomelinkComponent],
   
    entryComponents: [
      UseraddDialogComponent
    ],
})
export class MastersetupModule { }
