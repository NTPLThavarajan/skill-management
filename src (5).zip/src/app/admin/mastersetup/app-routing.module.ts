import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SkillmasterComponent } from '../mastersetup/skillmaster/skillmaster.component';
import { UserAddComponent } from '../mastersetup/user-add/user-add.component';
import { LocationmasterComponent } from '../mastersetup/locationmaster/locationmaster.component';
import { RatingmasterComponent } from '../mastersetup/ratingmaster/ratingmaster.component';
import { RollmasterComponent } from '../mastersetup/rollmaster/rollmaster.component';
import { HomelinkComponent } from './homelink/homelink.component';

const routes: Routes = [
  {
    path: '',
    component: HomelinkComponent,
    children: [
      {
        path: '',
        redirectTo: 'autocomplete'
      },
      {
        path: 'usermaster',
        component: UserAddComponent
      },
      {
        path: 'locationmaster',
        component: LocationmasterComponent
      },
      {
        path: 'ratingmaster',
        component: RatingmasterComponent
      },
      {
        path: 'rollmaster',
        component: RollmasterComponent
      },
      {
        path: 'skillmaster',
        component: SkillmasterComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
